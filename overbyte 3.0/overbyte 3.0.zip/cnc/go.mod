module overbyte-cnc

go 1.26.0

require (
	github.com/ergochat/readline v0.1.3
	github.com/go-sql-driver/mysql v1.9.3
	github.com/google/nftables v0.3.0
	golang.org/x/crypto v0.49.0
	golang.org/x/term v0.41.0
	gopkg.in/natefinch/lumberjack.v2 v2.2.1
)

require (
	filippo.io/edwards25519 v1.1.0 // indirect
	github.com/google/go-cmp v0.6.0 // indirect
	github.com/mdlayher/netlink v1.7.3-0.20250113171957-fbb4dce95f42 // indirect
	github.com/mdlayher/socket v0.5.0 // indirect
	golang.org/x/net v0.51.0 // indirect
	golang.org/x/sync v0.20.0 // indirect
	golang.org/x/sys v0.42.0 // indirect
	golang.org/x/text v0.35.0 // indirect
)
