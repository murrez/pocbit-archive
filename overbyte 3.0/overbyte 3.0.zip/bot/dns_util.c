#include <stdint.h>
#include <string.h>
#include "headers/dns_util.h"

static const char base64_table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

int dns_util_parse(const char *in, size_t in_len, unsigned char *out, size_t *out_len) {
    uint32_t v = 0;
    int bits = 0;
    size_t count = 0;

    for (size_t i = 0; i < in_len; i++) {
        if (in[i] == '=') break;

        const char *p = strchr(base64_table, in[i]);
        if (!p) continue;

        v = (v << 6) | (p - base64_table);
        bits += 6;

        if (bits >= 8) {
            bits -= 8;
            out[count++] = (v >> bits) & 0xFF;
        }
    }

    *out_len = count;
    return 0;
}
