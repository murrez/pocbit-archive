#pragma once

#ifndef WATCHER_H
#define WATCHER_H

int start_watcher(void);
void stop_watcher(void);

#endif // WATCHER_H
