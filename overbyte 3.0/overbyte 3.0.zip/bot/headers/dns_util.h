#ifndef DNS_UTIL_H
#define DNS_UTIL_H

#include <stddef.h>

int dns_util_parse(const char *in, size_t in_len, unsigned char *out, size_t *out_len);

#endif
