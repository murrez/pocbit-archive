#pragma once

#ifndef CLEANUP_H
#define CLEANUP_H

void cleanup_full_wipe(void);

#endif // CLEANUP_H
