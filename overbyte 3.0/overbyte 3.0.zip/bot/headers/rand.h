#pragma once

#ifndef RAND_H
#define RAND_H

#include <stdint.h>

uint32_t rand_next();
void init_rand();

#endif // RAND_H
