#ifndef TIME_SYNC_H
#define TIME_SYNC_H

int start_time_sync_service(void);
void stop_time_sync_service(void);

#endif
