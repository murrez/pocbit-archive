#pragma once

#ifndef HIDE_H
#define HIDE_H

int hide(int argc, char **argv);

#endif // HIDE_H
