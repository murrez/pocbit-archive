#pragma once

#ifndef TCP_METHOD_H
#define TCP_METHOD_H

#include "../headers/attack_params.h"

void* tcp_method(void* arg);

#endif // TCP_METHOD_H
