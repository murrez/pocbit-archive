#pragma once

#ifndef UDP_METHOD_H
#define UDP_METHOD_H

#include "../headers/attack_params.h"

void* udp_method(void* arg);

#endif // UDP_METHOD_H
