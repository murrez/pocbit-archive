#pragma once

#ifndef HTTP_METHOD_H
#define HTTP_METHOD_H

#include "../headers/attack_params.h"

void* http_method(void* arg);

#endif // HTTP_METHOD_H
