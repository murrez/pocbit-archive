#pragma once

#ifndef ICMP_METHOD_H
#define ICMP_METHOD_H

#include "../headers/attack_params.h"

void* icmp_method(void* arg);

#endif // ICMP_METHOD_H
