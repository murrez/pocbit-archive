#pragma once

#ifndef HTTPS_METHOD_H
#define HTTPS_METHOD_H

#include "../headers/attack_params.h"

void* https_method(void* arg);

#endif // HTTPS_METHOD_H
