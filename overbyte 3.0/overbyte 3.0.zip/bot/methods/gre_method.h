#pragma once

#ifndef GRE_METHOD_H
#define GRE_METHOD_H

#include "../headers/attack_params.h"

void* gre_method(void* arg);

#endif // GRE_METHOD_H
